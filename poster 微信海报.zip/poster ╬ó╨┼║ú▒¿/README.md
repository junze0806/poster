# poster
poster 微信小程序海报DEMO
## 新增图片自适应
![效果图](https://github.com/kingbuwu/poster/blob/master/images/img/1.png)
![效果图](https://github.com/kingbuwu/poster/blob/master/images/img/2.png)
